!#/bin/bash

python -m pip install pymongo
pip install tqdm
pip install xmltodict
pip install requests
pip install bs4
pip install argparse_prompt